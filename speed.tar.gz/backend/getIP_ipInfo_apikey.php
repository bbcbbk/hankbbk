<?php

// put your token between the quotes if you have one
$IPINFO_APIKEY = '4f6d42f1b48c45';
